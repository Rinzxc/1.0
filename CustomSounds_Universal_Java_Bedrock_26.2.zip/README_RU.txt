CUSTOMSOUNDS UNIVERSAL — JAVA 26.2 + BEDROCK

В архиве две отдельные регистрации звуков:
- Java Edition: pack.mcmeta + assets/customsounds/sounds.json
- Bedrock Edition: manifest.json + sounds/sound_definitions.json

СЛОТЫ
Есть 20 имён: sound1.ogg ... sound20.ogg
Идентификатор события для Java: customsounds:custom.sound1
Bedrock-регистрация использует тот же полный идентификатор события.

КАК ДОБАВИТЬ ЗВУК
Для каждого звука используй настоящий OGG-файл (не просто переименованный MP3/WAV).

1) Java:
assets/customsounds/sounds/custom/sound1.ogg

2) Bedrock:
sounds/custom/sound1.ogg

Нужно положить ОДИН И ТОТ ЖЕ файл в обе папки. У Java и Bedrock разные структуры папок;
одного физического файла в одном месте для двух движков недостаточно.

ПРОВЕРКА JAVA
В игре:
/playsound customsounds:custom.sound1 master @s
После изменения файлов нажми F3+T.

BEDROCK ЧЕРЕЗ GEYSER
Bedrock-часть находится в корне этого архива и может быть загружена Geyser как ZIP.
Положи ZIP в папку packs Geyser (обычно plugins/Geyser-Spigot/packs/) и перезапусти
сервер или перезагрузи Geyser. Bedrock-игроку нужно переподключиться; при проблемах
с новыми аудиофайлами полностью перезапустить клиент Minecraft Bedrock.

ВАЖНО ПРО GEYSER
Geyser не конвертирует Java resource packs автоматически. Этот архив уже содержит
Bedrock sound_definitions.json, но для передачи кастомных Java sound events игрокам
Bedrock может потребоваться отдельное сопоставление звуков Geyser (например, через
официальный инструмент Rainbow). Поэтому сначала проверь Java; Bedrock-проверку
сделаем после загрузки Bedrock-части в Geyser.
